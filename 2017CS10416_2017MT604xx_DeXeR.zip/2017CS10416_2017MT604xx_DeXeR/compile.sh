g++ -std=c++11 -O3 board.cpp -o player

